#include "telnet_if.h"

#include <string>

Telnet_interface* Telnet_interface::__telnet_if_singleton = nullptr;

extern struct TS3Functions ts3Functions;

const int TELNET_PORT = 23;
const char* TELNET_PORT_STR = "23";

const char* TEAMSPEAK_CMD_PREFIX = "ts3-";

//-----------------------------------------------------------------------------
/// Create instance if no instance exists yet
Telnet_interface* Telnet_interface::create_instance(const struct TS3Functions funcs) {
	if (Telnet_interface::__telnet_if_singleton == nullptr) {
		Telnet_interface::__telnet_if_singleton = new Telnet_interface(funcs);
	}
	return Telnet_interface::__telnet_if_singleton;
}

//-----------------------------------------------------------------------------
/// Returns the instance, nullptr if it doesn't exist
Telnet_interface* Telnet_interface::get_instance() {
	return Telnet_interface::__telnet_if_singleton;
}

//-----------------------------------------------------------------------------
/// Sets the TS3 functions
//void Telnet_interface::set_ts3_functions(struct TS3Functions * ts3Functions) {
//    Telnet_interface::__ts3Functions = ts3Functions;
//}

//-----------------------------------------------------------------------------
/// Destroys the instance
void Telnet_interface::destroy_instance() {
	if (Telnet_interface::__telnet_if_singleton != nullptr) {
		delete Telnet_interface::__telnet_if_singleton;
		Telnet_interface::__telnet_if_singleton = nullptr;
	}
}

//-----------------------------------------------------------------------------
/// Constructor
Telnet_interface::Telnet_interface(const struct TS3Functions funcs) {
	_state = TELNET_INTERFACE_STATE_IDLE;
    _server_socket = INVALID_SOCKET;
    _client_socket = INVALID_SOCKET;
    _ts3Functions = funcs;
}

//-----------------------------------------------------------------------------
/// Destructor
Telnet_interface::~Telnet_interface() {
	if (_state == TELNET_INTERFACE_STATE_LISTENING) {
		closesocket(_server_socket);
	} else if (_state == TELNET_INTERFACE_STATE_CONNECTED) {
		closesocket(_client_socket);
		closesocket(_server_socket);
	}
}

//-----------------------------------------------------------------------------
/// Starts the server
bool Telnet_interface::listen() {
    if (_state == TELNET_INTERFACE_STATE_IDLE) {
        struct addrinfo *result = NULL, *ptr = NULL, hints;

        ZeroMemory(&hints, sizeof (hints));
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;
        hints.ai_flags = AI_PASSIVE;

        // Resolve the local address and port to be used by the server
        int int_result = getaddrinfo(NULL, TELNET_PORT_STR, &hints, &result);
        if (int_result != 0) {
            WSACleanup();
            return false;
        }

        // Assign the server socket
        _server_socket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
        if (_server_socket == INVALID_SOCKET) {
            freeaddrinfo(result);
            WSACleanup();
            return 1;
        }

        // Setup the TCP listening socket
        int_result = bind(_server_socket, result->ai_addr, (int)result->ai_addrlen);
        if (int_result == SOCKET_ERROR) {
            freeaddrinfo(result);
            closesocket(_server_socket);
            WSACleanup();
            return false;
        }

        // Listen on the socket
        if (::listen(_server_socket, 1) == SOCKET_ERROR) {
            closesocket(_server_socket);
            WSACleanup();
            return false;
        }

        // Change the state - server is now listening
        _change_state(TELNET_INTERFACE_STATE_LISTENING);
        return true;
    }
    else {
        _ts3Functions.logMessage("Interface is already listening for connections", LogLevel_INFO, "", 0);
        return false;
    }
}

//-----------------------------------------------------------------------------
/// Executes the thread
void Telnet_interface::execute() {
    switch (_state) {
    case TELNET_INTERFACE_STATE_IDLE:      _run_TELNET_INTERFACE_STATE_IDLE(); break;
    case TELNET_INTERFACE_STATE_LISTENING: _run_TELNET_INTERFACE_STATE_LISTENING(); break;
    case TELNET_INTERFACE_STATE_CONNECTED: _run_TELNET_INTERFACE_STATE_CONNECTED(); break;
    }
}

//-----------------------------------------------------------------------------
/// Changes the current state of the interface
void Telnet_interface::_change_state(Telnet_interface_state state) {
    // Call the appropriate On Exit function
    switch (_state) {
    case TELNET_INTERFACE_STATE_IDLE:      _on_exit_TELNET_INTERFACE_STATE_IDLE(); break;
    case TELNET_INTERFACE_STATE_LISTENING: _on_exit_TELNET_INTERFACE_STATE_LISTENING(); break;
    case TELNET_INTERFACE_STATE_CONNECTED: _on_exit_TELNET_INTERFACE_STATE_CONNECTED(); break;
    }

    // Update the state
    _state = state;

    // Call the appropriate On Enter function
    switch (_state) {
    case TELNET_INTERFACE_STATE_IDLE:      _on_enter_TELNET_INTERFACE_STATE_IDLE(); break;
    case TELNET_INTERFACE_STATE_LISTENING: _on_enter_TELNET_INTERFACE_STATE_LISTENING(); break;
    case TELNET_INTERFACE_STATE_CONNECTED: _on_enter_TELNET_INTERFACE_STATE_CONNECTED(); break;
    }
}

//-----------------------------------------------------------------------------
/// Enters the IDLE state
void Telnet_interface::_on_enter_TELNET_INTERFACE_STATE_IDLE() {
    _ts3Functions.logMessage("Entering IDLE state", LogLevel_DEBUG, "", 0);
}

//-----------------------------------------------------------------------------
/// Enters the LISTENING state
void Telnet_interface::_on_enter_TELNET_INTERFACE_STATE_LISTENING() {
    _ts3Functions.logMessage("Entering LISTENING state", LogLevel_DEBUG, "", 0);
}

//-----------------------------------------------------------------------------
/// Enters the CONNECTED state
void Telnet_interface::_on_enter_TELNET_INTERFACE_STATE_CONNECTED() {
    _ts3Functions.logMessage("Entering CONNECTED state", LogLevel_DEBUG, "", 0);
}

//-----------------------------------------------------------------------------
/// Runs the IDLE state
void Telnet_interface::_run_TELNET_INTERFACE_STATE_IDLE() {}

//-----------------------------------------------------------------------------
/// Runs the LISTENING state
void Telnet_interface::_run_TELNET_INTERFACE_STATE_LISTENING() {
    timeval timeout;
    timeout.tv_sec = 1;
    timeout.tv_usec = 0;

    fd_set readfds;
    FD_ZERO(&readfds);
    FD_SET(_server_socket, &readfds);

    if (select(1, &readfds, NULL, NULL, &timeout) > 0) {

        _client_socket = accept(_server_socket, NULL, NULL);
        if (_client_socket == INVALID_SOCKET) {
            _ts3Functions.logMessage("Invalid client socket, closing server socket", LogLevel_INFO, "", 0);
            closesocket(_server_socket);
            WSACleanup();
        }
        else {
            _ts3Functions.logMessage("Client socket connected!", LogLevel_INFO, "", 0);
            _change_state(TELNET_INTERFACE_STATE_CONNECTED);
        }
    }
}

//-----------------------------------------------------------------------------
/// Runs the CONNECTED state
void Telnet_interface::_run_TELNET_INTERFACE_STATE_CONNECTED() {
    timeval timeout;
    timeout.tv_sec = 1;
    timeout.tv_usec = 0;

    fd_set read_fds, write_fds;
    FD_ZERO(&read_fds);
    FD_ZERO(&write_fds);
    FD_SET(_client_socket, &read_fds);
    FD_SET(_client_socket, &write_fds);

    if (select(1, &read_fds, &write_fds, NULL, &timeout) > 0) {
        if (FD_ISSET(_client_socket, &read_fds)) {
            _ts3Functions.logMessage("Client ready for reading!", LogLevel_DEBUG, "", 0);

            char buffer[100];
            int bytes_received = recv(_client_socket, buffer, sizeof(buffer), 0);
            if (bytes_received > 0) {
                _ts3Functions.logMessage("Got bytes from client", LogLevel_DEBUG, "", 0);
                _read_stream.write(buffer, bytes_received);
                _parse_buffer();
            }
            else {
                _ts3Functions.logMessage("Client disconnected", LogLevel_INFO, "", 0);
                closesocket(_client_socket);
                _client_socket = INVALID_SOCKET;
                _change_state(TELNET_INTERFACE_STATE_LISTENING);
            }
        }

    }
}

//-----------------------------------------------------------------------------
/// Exits the IDLE state
void Telnet_interface::_on_exit_TELNET_INTERFACE_STATE_IDLE() {
    _ts3Functions.logMessage("Exiting IDLE state", LogLevel_DEBUG, "", 0);
}

//-----------------------------------------------------------------------------
/// Exits the LISTENING state
void Telnet_interface::_on_exit_TELNET_INTERFACE_STATE_LISTENING() {
    _ts3Functions.logMessage("Exiting LISTENING state", LogLevel_DEBUG, "", 0);
}

//-----------------------------------------------------------------------------
/// Exits the CONNECTED state
void Telnet_interface::_on_exit_TELNET_INTERFACE_STATE_CONNECTED() {
    _ts3Functions.logMessage("Exiting CONNECTED state", LogLevel_DEBUG, "", 0);
}

//-----------------------------------------------------------------------------
/// Parses the content of the received buffer
void Telnet_interface::_parse_buffer() {
    std::string line;
    std::getline(_read_stream, line);

    std::istringstream parser(line);
    std::string identifier;
    std::getline(parser, identifier, '-');

    if (identifier == "ts3") {
        _ts3Functions.logMessage("Found command", LogLevel_DEBUG, "", 0);

        std::string command;
        std::getline(parser, command, ' ');
    }
}

//=============================================================================
// Helper that extracts the ts3-<name><space> commands

const char* helper_get_command(char* buffer, int buffer_size, int *command_offset) {
    if (strstr(buffer, TEAMSPEAK_CMD_PREFIX) == 0) {
        return buffer + strlen(TEAMSPEAK_CMD_PREFIX);
    }
    else {
        //ts3Functions.logMessage("Could not find TeamSpeak Command Prefix", LogLevel_INFO, "", 0);
        return NULL;
    }
}

//=============================================================================
// Process the command contained in the buffer
void process_command(const char* command, int buffer_size) {
    if (!strstr(command, "config-add-identifier")){

    }
    else if (!strstr(command, "config-remove-identifier")){

    }
    else if (!strstr(command, "connect")){

    }
    else if (!strstr(command, "disconnect")){

    }
}